﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PropertyManagement.Models;

namespace PropertyManagement.Data
{
    public class HomeDBContext : DbContext
    {
        public HomeDBContext (DbContextOptions<HomeDBContext> options)
            : base(options)
        {
        }

        public DbSet<PropertyManagement.Models.House> House { get; set; } = default!;
    }
}
