﻿using System.ComponentModel.DataAnnotations;

namespace PropertyManagement.Models
{
    public class House
    {
        public int Id { get; set; }
        [Required]
        [MaxLength(255)]
        [Display(Name="Owner's name")]
        [DataType(DataType.Text)]
        public string? OwnerName{ get; set; }
        [Required]
        [MaxLength(255)]
        [Display(Name = "Property name")]
        [DataType(DataType.Text)]

        public string? MyProperty { get; set;}
        [Required]
       // [MaxLength(255)]
        [Display(Name = "Property Value")]
        [DataType(DataType.Currency)]
        public int PropertyValue { get; set; }  

    }
}
